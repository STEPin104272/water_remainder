package com.example.water_rem_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
